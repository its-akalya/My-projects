import { Request, Response, NextFunction } from 'express';

/**
 * Middleware to validate item input for creation and updates.
 */
export const validateItem = (req: Request, res: Response, next: NextFunction) => {
  const { name, category, quantity, price } = req.body;

  if (!name || typeof name !== 'string') {
    return res.status(400).json({ error: 'Name is required and must be a string' });
  }

  if (!category || typeof category !== 'string') {
    return res.status(400).json({ error: 'Category is required and must be a string' });
  }

  if (quantity === undefined || typeof quantity !== 'number' || quantity < 0) {
    return res.status(400).json({ error: 'Quantity is required and must be a non-negative number' });
  }

  if (price === undefined || typeof price !== 'number' || price < 0) {
    return res.status(400).json({ error: 'Price is required and must be a non-negative number' });
  }

  next();
};
