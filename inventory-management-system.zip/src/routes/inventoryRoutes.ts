import { Router } from 'express';
import * as inventoryController from '../controllers/inventoryController';
import { validateItem } from '../middleware/validation';

const router = Router();

// CRUD Endpoints
router.get('/', inventoryController.getAllItems);
router.get('/:id', inventoryController.getItemById);
router.post('/', validateItem, inventoryController.addItem);
router.put('/:id', validateItem, inventoryController.updateItem);
router.delete('/:id', inventoryController.deleteItem);

export default router;
