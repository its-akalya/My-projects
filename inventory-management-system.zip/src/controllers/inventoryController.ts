import { Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { getInventory, setInventory, InventoryItem } from '../model/inventoryData';

/**
 * Fetch all items with optional searching and filtering.
 */
export const getAllItems = (req: Request, res: Response) => {
  let items = getInventory();
  const { name, category, minQuantity } = req.query;

  // Searching by name
  if (name) {
    items = items.filter(item => 
      item.name.toLowerCase().includes(String(name).toLowerCase())
    );
  }

  // Filtering by category
  if (category) {
    items = items.filter(item => 
      item.category.toLowerCase() === String(category).toLowerCase()
    );
  }

  // Filtering by quantity
  if (minQuantity) {
    items = items.filter(item => item.quantity >= Number(minQuantity));
  }

  res.json(items);
};

/**
 * Fetch a single item by ID.
 */
export const getItemById = (req: Request, res: Response) => {
  const item = getInventory().find(i => i.id === req.params.id);
  if (!item) {
    return res.status(404).json({ error: 'Item not found' });
  }
  res.json(item);
};

/**
 * Add a new item to inventory.
 */
export const addItem = (req: Request, res: Response) => {
  const { name, category, quantity, price } = req.body;
  const newItem: InventoryItem = {
    id: uuidv4(),
    name,
    category,
    quantity,
    price,
    updatedAt: new Date().toISOString()
  };

  const currentInventory = getInventory();
  setInventory([...currentInventory, newItem]);
  
  res.status(201).json(newItem);
};

/**
 * Update an existing item.
 */
export const updateItem = (req: Request, res: Response) => {
  const { id } = req.params;
  const { name, category, quantity, price } = req.body;
  
  const currentInventory = getInventory();
  const index = currentInventory.findIndex(i => i.id === id);

  if (index === -1) {
    return res.status(404).json({ error: 'Item not found' });
  }

  const updatedItem: InventoryItem = {
    ...currentInventory[index],
    name,
    category,
    quantity,
    price,
    updatedAt: new Date().toISOString()
  };

  const newInventory = [...currentInventory];
  newInventory[index] = updatedItem;
  setInventory(newInventory);

  res.json(updatedItem);
};

/**
 * Delete an item from inventory.
 */
export const deleteItem = (req: Request, res: Response) => {
  const { id } = req.params;
  const currentInventory = getInventory();
  const exists = currentInventory.some(i => i.id === id);

  if (!exists) {
    return res.status(404).json({ error: 'Item not found' });
  }

  const newInventory = currentInventory.filter(i => i.id !== id);
  setInventory(newInventory);

  res.json({ message: 'Item deleted successfully' });
};
