/**
 * In-memory data store for the inventory.
 * In a real-world app, this would be replaced by a database connection.
 */

export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  quantity: number;
  price: number;
  updatedAt: string;
}

let inventory: InventoryItem[] = [
  {
    id: "1",
    name: "Laptop",
    category: "Electronics",
    quantity: 15,
    price: 999.99,
    updatedAt: new Date().toISOString()
  },
  {
    id: "2",
    name: "Office Chair",
    category: "Furniture",
    quantity: 30,
    price: 150.00,
    updatedAt: new Date().toISOString()
  }
];

export const getInventory = () => inventory;
export const setInventory = (newInventory: InventoryItem[]) => {
  inventory = newInventory;
};
