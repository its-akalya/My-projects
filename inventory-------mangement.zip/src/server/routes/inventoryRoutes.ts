import express from 'express';
import * as inventoryController from '../controllers/inventoryController.ts';
import { validateItem } from '../middleware/validation.ts';

const router = express.Router();

router.get('/', inventoryController.getAllItems);
router.get('/:id', inventoryController.getItemById);
router.post('/', validateItem, inventoryController.addItem);
router.put('/:id', validateItem, inventoryController.updateItem);
router.delete('/:id', inventoryController.deleteItem);

export default router;
