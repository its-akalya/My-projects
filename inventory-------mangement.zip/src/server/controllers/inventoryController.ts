import { Request, Response, NextFunction } from 'express';
import { inventory, InventoryItem } from '../model/inventoryData.ts';

export const getAllItems = (req: Request, res: Response) => {
  let filteredItems = [...inventory];
  const { name, category, quantity, minQuantity } = req.query;

  if (name) {
    filteredItems = filteredItems.filter(item => 
      item.name.toLowerCase().includes(String(name).toLowerCase())
    );
  }

  if (category) {
    filteredItems = filteredItems.filter(item => 
      item.category.toLowerCase() === String(category).toLowerCase()
    );
  }

  if (quantity) {
    filteredItems = filteredItems.filter(item => 
      item.quantity === Number(quantity)
    );
  }

  if (minQuantity) {
    filteredItems = filteredItems.filter(item => 
      item.quantity >= Number(minQuantity)
    );
  }

  res.json(filteredItems);
};

export const getItemById = (req: Request, res: Response) => {
  const item = inventory.find(i => i.id === req.params.id);
  if (!item) {
    return res.status(404).json({ message: 'Item not found' });
  }
  res.json(item);
};

export const addItem = (req: Request, res: Response) => {
  const { name, category, quantity, price } = req.body;
  const newItem: InventoryItem = {
    id: Math.random().toString(36).substr(2, 9),
    name,
    category,
    quantity: Number(quantity),
    price: Number(price),
    createdAt: new Date().toISOString()
  };
  inventory.push(newItem);
  res.status(201).json(newItem);
};

export const updateItem = (req: Request, res: Response) => {
  const index = inventory.findIndex(i => i.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ message: 'Item not found' });
  }

  const { name, category, quantity, price } = req.body;
  inventory[index] = {
    ...inventory[index],
    name: name || inventory[index].name,
    category: category || inventory[index].category,
    quantity: quantity !== undefined ? Number(quantity) : inventory[index].quantity,
    price: price !== undefined ? Number(price) : inventory[index].price,
  };

  res.json(inventory[index]);
};

export const deleteItem = (req: Request, res: Response) => {
  const index = inventory.findIndex(i => i.id === req.params.id);
  if (index === -1) {
    return res.status(404).json({ message: 'Item not found' });
  }
  const deletedItem = inventory.splice(index, 1);
  res.json({ message: 'Item deleted', item: deletedItem[0] });
};
