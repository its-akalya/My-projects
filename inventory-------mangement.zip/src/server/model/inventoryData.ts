export interface InventoryItem {
  id: string;
  name: string;
  category: string;
  quantity: number;
  price: number;
  createdAt: string;
}

export let inventory: InventoryItem[] = [
  {
    id: '1',
    name: 'Laptop',
    category: 'Electronics',
    quantity: 10,
    price: 999.99,
    createdAt: new Date().toISOString()
  },
  {
    id: '2',
    name: 'Office Chair',
    category: 'Furniture',
    quantity: 15,
    price: 199.50,
    createdAt: new Date().toISOString()
  }
];
