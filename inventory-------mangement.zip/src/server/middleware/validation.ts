import { Request, Response, NextFunction } from 'express';

export const validateItem = (req: Request, res: Response, next: NextFunction) => {
  const { name, category, quantity, price } = req.body;

  // For POST requests, all fields are required
  if (req.method === 'POST') {
    if (!name || !category || quantity === undefined || price === undefined) {
      return res.status(400).json({ 
        error: 'Validation Failed', 
        details: 'name, category, quantity, and price are required' 
      });
    }
  }

  // Type checks if present
  if (name && typeof name !== 'string') return res.status(400).json({ error: 'name must be a string' });
  if (category && typeof category !== 'string') return res.status(400).json({ error: 'category must be a string' });
  if (quantity !== undefined && (typeof quantity !== 'number' || quantity < 0)) {
    return res.status(400).json({ error: 'quantity must be a non-negative number' });
  }
  if (price !== undefined && (typeof price !== 'number' || price < 0)) {
    return res.status(400).json({ error: 'price must be a non-negative number' });
  }

  next();
};
